/*
  Copyright (c) 2011 Arduino.  All right reserved.
  Copyright (c) 2014 Intel Corporation.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <Arduino.h>
#include <interrupt.h>
#include <Mux.h>
#include <sysfs.h>
#include <trace.h>
#include "variant.h"

//Bindings to Arduino
#include "RingBuffer.h"
#include "TTYUART.h"
#include "fast_gpio_pci.h"

#define MY_TRACE_PREFIX "variant"

// Mucked up Kurt to try to work with Intel Breakout Board...

#ifdef __cplusplus
extern "C" {
#endif

#define GP12_PWM0			12
#define GP13_PWM1			13
#define GP182_PWM2			182
#define GP183_PWM3			183
#define any_equal(a,b,c,d)		(a==b||a==c||a==d||b==c||b==d||c==d)
#define all_pwms(a,b,c,d)		(digitalPinHasPWM(a)&&digitalPinHasPWM(b)&&\
					digitalPinHasPWM(c)&&digitalPinHasPWM(d))

struct pwm_muxing {
	uint8_t gpioid;
	mux_sel_t *muxing;
};

/*
const int mux_sel_analog[NUM_ANALOG_INPUTS] = {
	MUX_SEL_AD7298_VIN0,
	MUX_SEL_AD7298_VIN1,
	MUX_SEL_AD7298_VIN2,
	MUX_SEL_AD7298_VIN3,
	MUX_SEL_AD7298_VIN4,
	MUX_SEL_AD7298_VIN5,
};
*/

const int mux_sel_uart[NUM_UARTS][MUX_DEPTH_UART] = {
	/* This is auto-indexed (board pinout) */
	{MUX_SEL_NONE, MUX_SEL_NONE},				// ttyGS0 - USB not muxed
	{MUX_SEL_UART0_RXD,	MUX_SEL_UART0_TXD},		// ttyS0 - muxed
};

const int  mux_sel_spi[NUM_SPI][MUX_DEPTH_SPI] = {
	{
		MUX_SEL_NONE,
		MUX_SEL_NONE,
		MUX_SEL_NONE
	},
	{
		MUX_SEL_SPI1_MOSI,
		MUX_SEL_SPI1_MISO,
		MUX_SEL_SPI1_SCK
	},
};

const int  mux_sel_i2c[NUM_I2C][MUX_DEPTH_I2C] = {
	{
		MUX_SEL_I2C_SCL,
		MUX_SEL_I2C_SDA,
	},
};
                        //gpio, value, type
mux_sel_t MuxDesc0[] = {{ 182, PIN_MODE_0, FN_GPIO } }; // GPIO mode

mux_sel_t MuxDesc4[] = {{ 135, PIN_MODE_0, FN_GPIO } }; // GPIO mode

mux_sel_t MuxDesc6[] = {{ 27, PIN_MODE_0, FN_GPIO } ,  // GPIO mode
                         { 27, PIN_MODE_1, FN_I2C }};   // I2C mode
mux_sel_t MuxDesc7[] = {{ 20, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc8[] = {{ 28, PIN_MODE_0, FN_GPIO } , // GPIO mode
                         { 28, PIN_MODE_1, FN_I2C }};   // I2C mode
mux_sel_t MuxDesc9[] = {{ 111, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc10[] = {{ 109, PIN_MODE_0, FN_GPIO },  // GPIO mode
                         { 109, PIN_MODE_1, FN_SPI }}; // SPI mode
mux_sel_t MuxDesc11[] = {{ 115, PIN_MODE_0, FN_GPIO }, // GPIO mode
                         { 115, PIN_MODE_1, FN_SPI }}; // SPI mode

mux_sel_t MuxDesc13[] = {{ 128, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc14[] = {{ 13, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc15[] = {{ 165, PIN_MODE_0, FN_GPIO } }; // GPIO mode

mux_sel_t MuxDesc19[] = {{19, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc20[] = {{ 12, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc21[] = {{ 183, PIN_MODE_0, FN_GPIO } }; // GPIO mode

mux_sel_t MuxDesc23[] = {{ 110, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc24[] = {{ 114, PIN_MODE_0, FN_GPIO }, // GPIO mode
                         { 114, PIN_MODE_1, FN_SPI }}; // SPI mode
mux_sel_t MuxDesc25[] = {{ 129, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc26[] = {{ 130, PIN_MODE_0, FN_GPIO }, // GPIO mode
                         { 130, PIN_MODE_1, FN_UART }}; // UART mode


mux_sel_t MuxDesc31[] = {{ 44, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc32[] = {{ 46, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc33[] = {{ 48, PIN_MODE_0, FN_GPIO } }; // GPIO mode

mux_sel_t MuxDesc35[] = {{ 131, PIN_MODE_0, FN_GPIO },  // GPIO mode
                         { 131, PIN_MODE_1, FN_UART }}; // UART mode

mux_sel_t MuxDesc36[] = {{ 14, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc37[] = {{ 40, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc38[] = {{ 43, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc39[] = {{ 77, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc40[] = {{ 82, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc41[] = {{ 83, PIN_MODE_0, FN_GPIO } }; // GPIO mode

mux_sel_t MuxDesc44[] = {{ 134, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc45[] = {{ 45, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc46[] = {{ 47, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc47[] = {{ 49, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc48[] = {{ 15, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc49[] = {{ 84, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc50[] = {{ 42, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc51[] = {{ 41, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc52[] = {{ 78, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc53[] = {{ 79, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc54[] = {{ 80, PIN_MODE_0, FN_GPIO } }; // GPIO mode
mux_sel_t MuxDesc55[] = {{ 81, PIN_MODE_0, FN_GPIO } }; // GPIO mode



// Sorted by Linux GPIO ID
PinDescription g_APinDescription[] =
{
// BUGBUG: pass 1 fast info only for ones that match arduino...
//	gpiolib	alias	fastinf	ardid	Initial		FixdSt	    ptMuxDesc,		        MuxCount		    type	   Handle  extPU	iAlt	pAlt
    {12,    NONE,   3,	20,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc20,	MUX_SIZE(MuxDesc20),	FN_GPIO,	-1,     0,	0,	NULL },	
    {13,    NONE,   5,	14,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc14,	MUX_SIZE(MuxDesc14),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {14,    NONE,   18,	36,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc36,	MUX_SIZE(MuxDesc36),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {15,    NONE,   NONE,	48,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc48,	MUX_SIZE(MuxDesc48),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {19,    NONE,   NONE,	19,	NONE,           	NONE,	(mux_sel_t*)&MuxDesc19,	MUX_SIZE(MuxDesc19),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {20,    NONE,   NONE,	7,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc7,	MUX_SIZE(MuxDesc7),	    FN_GPIO,	-1,	    0,	0,	NULL },	
    {27,    NONE,   NONE,	6,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc6,	MUX_SIZE(MuxDesc6), 	FN_GPIO,	-1,	    0,	0,	NULL },	
    {28,    NONE,   NONE,	8,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc8,	MUX_SIZE(MuxDesc8), 	FN_GPIO,	-1,	    0,	0,	NULL },	
    {40,    NONE,   13, 	37,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc37,	MUX_SIZE(MuxDesc37),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {41,    NONE,   10, 	51,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc51,	MUX_SIZE(MuxDesc51),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {42,    NONE,   12,	    50,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc50,	MUX_SIZE(MuxDesc50),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {43,    NONE,   11,	    38,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc38,	MUX_SIZE(MuxDesc38),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {44,    NONE,   14,	    31,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc31,	MUX_SIZE(MuxDesc31),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {45,    NONE,   15,	    45,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc45,	MUX_SIZE(MuxDesc45),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {46,    NONE,   16,	    32,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc32,	MUX_SIZE(MuxDesc32),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {47,    NONE,   17,	    46,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc46,	MUX_SIZE(MuxDesc46),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {48,    NONE,   7,	    33,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc33,	MUX_SIZE(MuxDesc33),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {49,    NONE,   8,  	47,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc47,	MUX_SIZE(MuxDesc47),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {77,    NONE,   NONE,	39,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc39,	MUX_SIZE(MuxDesc39),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {78,    NONE,   NONE,	52,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc52,	MUX_SIZE(MuxDesc52),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {79,    NONE,   NONE,	53,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc53,	MUX_SIZE(MuxDesc53),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {80,    NONE,   NONE,	54,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc54,	MUX_SIZE(MuxDesc54),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {81,    NONE,   NONE,	55,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc55,	MUX_SIZE(MuxDesc55),	FN_GPIO,	-1,	    0,	0,	NULL },
    {82,    NONE,   NONE,	40,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc40,	MUX_SIZE(MuxDesc40),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {83,    NONE,   NONE,	41,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc41,	MUX_SIZE(MuxDesc41),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {84,    NONE,   NONE,	49,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc49,	MUX_SIZE(MuxDesc49),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {109,   NONE,   NONE,	10,	NONE,           	NONE,	(mux_sel_t*)&MuxDesc10,	MUX_SIZE(MuxDesc10),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {110,   NONE,   NONE,	23,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc23,	MUX_SIZE(MuxDesc23),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {111,   NONE,   NONE,   9,	NONE,           	NONE,	(mux_sel_t*)&MuxDesc9,	MUX_SIZE(MuxDesc9),	    FN_GPIO,	-1,	    0,	0,	NULL },	
    {114,   NONE,   NONE,	24,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc24,	MUX_SIZE(MuxDesc24),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {115,   NONE,   NONE,	11,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc11,	MUX_SIZE(MuxDesc11),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {128,   NONE,   2,  	13,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc13,	MUX_SIZE(MuxDesc13),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {129,   NONE,   4,	    25,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc25,	MUX_SIZE(MuxDesc25),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {130,   NONE,   0,	    26,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc26,	MUX_SIZE(MuxDesc26),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {131,   NONE,   1,	    35,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc35,	MUX_SIZE(MuxDesc35),	FN_GPIO,	-1,	    0 ,	0,	NULL },	
    {135,   NONE,   NONE,	4,	NONE,	            NONE,	(mux_sel_t*)&MuxDesc4,	MUX_SIZE(MuxDesc4), 	FN_GPIO,	-1,	    0,	0,	NULL },	
    {165,   NONE,   19,	15,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc15,	MUX_SIZE(MuxDesc15),	FN_GPIO,	-1,	    0,	0,	NULL },	
    {182,   NONE,   6,	0,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc0,	MUX_SIZE(MuxDesc0),	    FN_GPIO,	-1,	    0,	0,	NULL },	
    {183,   NONE,   9,	21,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc21,	MUX_SIZE(MuxDesc21),	FN_GPIO,	-1,	    0,	0,	NULL }
};




uint32_t sizeof_g_APinDescription;

uint32_t ardPin2DescIdx[GPIO_TOTAL];

// Sorted by Linux PWM ID
PwmDescription g_APwmDescription[] = {
	{ 0,	20,	-1,	-1,	GP12_PWM0,	-1 },
	{ 1,	14,	-1,	-1,	GP13_PWM1,	-1 },
	{ 2,	0,	-1,	-1,	GP182_PWM2,	-1 },
	{ 3,	21,	-1,	-1,	GP183_PWM3,	-1 },
};
uint32_t sizeof_g_APwmDescription;

AdcDescription g_AdcDescription[] = {
	{ 0,	-1 },
	{ 1,	-1 },
	{ 2,	-1 },
	{ 3,	-1 },
	{ 4,	-1 },
	{ 5,	-1 },
};
uint32_t sizeof_g_AdcDescription;

// Sorted Arduino Pin ID
PinState g_APinState[]=
{
	/* uCurrentPwm	uPwmEnabled	uCurrentInput	uCurrentAdc		*/
	{ 0,		0,		1,		0},	/* 0		*/
	{ 0,		0,		1,		0},	/* 1		*/
	{ 0,		0,		1,		0},	/* 2		*/
	{ 0,		0,		1,		0},	/* 3  - PWM	*/
	{ 0,		0,		1,		0},	/* 4 		*/
	{ 0,		0,		1,		0},	/* 5  - PWM 	*/
	{ 0,		0,		1,		0},	/* 6  - PWM	*/
	{ 0,		0,		1,		0},	/* 7 		*/
	{ 0,		0,		1,		0},	/* 8 		*/
	{ 0,		0,		1,		0},	/* 9  - PWM	*/
	{ 0,		0,		1,		0},	/* 10 - PWM	*/
	{ 0,		0,		1,		0},	/* 11 - PMW	*/
	{ 0,		0,		1,		0},	/* 12		*/
	{ 0,		0,		1,		0},	/* 13		*/
	{ 0,		0,		1,		0},	/* 14 - 	*/
	{ 0,		0,		1,		0},	/* 15 - 	*/
	{ 0,		0,		1,		0},	/* 16 - 	*/
	{ 0,		0,		1,		0},	/* 17 - 	*/
	{ 0,		0,		1,		0},	/* 18 - 	*/
	{ 0,		0,		1,		0},	/* 19 - 	*/
	{ 0,		0,		1,		0},	/* 20 - 	*/
	{ 0,		0,		1,		0},	/* 21 - 	*/
	{ 0,		0,		1,		0},	/* 22 - 	*/
	{ 0,		0,		1,		0},	/* 23 - 	*/
	{ 0,		0,		1,		0},	/* 24 - 	*/
	{ 0,		0,		1,		0},	/* 25 - 	*/
	{ 0,		0,		1,		0},	/* 26 - 	*/
	{ 0,		0,		1,		0},	/* 27 - 	*/
	{ 0,		0,		1,		0},	/* 28 - 	*/
	{ 0,		0,		1,		0},	/* 29 - 	*/
	{ 0,		0,		1,		0},	/* 30 - 	*/
	{ 0,		0,		1,		0},	/* 31 - 	*/
	{ 0,		0,		1,		0},	/* 32 - 	*/
	{ 0,		0,		1,		0},	/* 33 - 	*/
	{ 0,		0,		1,		0},	/* 34 - 	*/
	{ 0,		0,		1,		0},	/* 35 - 	*/
	{ 0,		0,		1,		0},	/* 36 - 	*/
	{ 0,		0,		1,		0},	/* 37 - 	*/
	{ 0,		0,		1,		0},	/* 38 - 	*/
	{ 0,		0,		1,		0},	/* 39 - 	*/
	{ 0,		0,		1,		0},	/* 40 - 	*/
	{ 0,		0,		1,		0},	/* 41 - 	*/
	{ 0,		0,		1,		0},	/* 42 - 	*/
	{ 0,		0,		1,		0},	/* 43 - 	*/
	{ 0,		0,		1,		0},	/* 44 - 	*/
	{ 0,		0,		1,		0},	/* 45 - 	*/
	{ 0,		0,		1,		0},	/* 46 - 	*/
	{ 0,		0,		1,		0},	/* 47 - 	*/
	{ 0,		0,		1,		0},	/* 48 - 	*/
	{ 0,		0,		1,		0},	/* 49 - 	*/
	{ 0,		0,		1,		0},	/* 50 - 	*/
	{ 0,		0,		1,		0},	/* 51 - 	*/
	{ 0,		0,		1,		0},	/* 52 - 	*/
	{ 0,		0,		1,		0},	/* 53 - 	*/
	{ 0,		0,		1,		0},	/* 54 - 	*/
	{ 0,		0,		1,		0},	/* 55 - 	*/
};
uint32_t sizeof_g_APinState;

#ifdef __cplusplus
}
#endif


RingBuffer rx_buffer1;
RingBuffer rx_buffer2;
RingBuffer rx_buffer3;

TTYUARTClass Serial(&rx_buffer1, 0, false);	// ttyGS0  (USB serial)
TTYUARTClass Serial1(&rx_buffer2, 1, false);	// ttyMFD1(IO0/1)
TTYUARTClass Serial2(&rx_buffer3, 2, true);	// ttyMFD2 (system console)


// ----------------------------------------------------------------------------

int variantPinMode(uint8_t pin, uint8_t mode)
{
	/*
	 * Standard (sysfs) or fast-mode UIO options are available for some pins
	 *
	 * The pin at this time is set to Fast-mode by default, if available
	 */

	int ret = 0;
	PinDescription *p = NULL;

	/* Search for entry */
	if ((p = pinDescriptionById(pin)) == NULL) {
		trace_error("%s: invalid pin %u\n", __func__, pin);
		return PIN_EINVAL;
	}

	/* Alternate entries for Fast-Mode GPIO: enable by default if available */
	if (p->pAlternate) {
		p->iAlternate = 1;
		trace_debug("%s: enable Fast-Mode SoC GPIO for pin%u",
			    __func__, pin);
	}
	
	return 0;
}

int variantPinModeIRQ(uint8_t pin, uint8_t mode)
{
	return 0;
}

/*
 * Set the pin as used for PWM and do the muxing at SoC level to enable
 * the PWM output.
 */
void turnOnPWM(uint8_t pin)
{
	int i;

	/* Mark PWM enabled on pin */
	g_APinState[pin].uCurrentPwm = 1;
	g_APinState[pin].uCurrentAdc = 0;

	for (i = 0; i < sizeof_g_APwmDescription; i++)
		if (g_APwmDescription[i].ulArduinoId == pin) {
			sysfsGpioSetCurrentPinmux(g_APwmDescription[i].pwmChPinId,
					PIN_MODE_1);
			break;
		}
}

#define SYSFS_BUF		0x50
int variantGpioSetDrive(unsigned int gpio, unsigned int mode)
{
	FILE *fp = NULL;
	int ret = 0;
	char value[8] = "";
	char fs_path[SYSFS_BUF] = "";

	trace_debug("%s: gpio%u, mode=%u", __func__, gpio, mode);
    
	switch(mode) {
	case GPIO_DRIVE_PULLUP:
		strcpy(value, "pullup");
		break;
	case GPIO_DRIVE_PULLDOWN:
		strcpy(value, "pulldown");
		break;
	case GPIO_DRIVE_STRONG:
        return -1;
		break;
	case GPIO_DRIVE_HIZ:
		strcpy(value, "nopull");
		break;
	default:
		trace_error("%s: unknown mode %u", __func__, mode);
		return -1;
	}

	/* Set GPIO direction  */
	snprintf(fs_path, sizeof(fs_path), LINUX_GPIO_DRIVE_FMT, gpio);
	if (NULL == (fp = fopen(fs_path, "rb+"))) {
		trace_error("err set drive fs_path=%s\n", fs_path);
		return -1;
	}
	rewind(fp);

	fwrite(&value, sizeof(char), sizeof(value), fp);
	fclose(fp);

	return 1;   // we handled it. 
}

void turnOffPWM(uint8_t pin)
{
	int handle = 0, ret = 0;
	PinDescription *p = NULL;

	// Scan mappings
	if ((p = pinDescriptionById(pin)) == NULL) {
		trace_error("%s: invalid pin %u\n", __func__, pin);
		return;
	}

	pin2alternate(&p);

	if(p->ulArduinoId == pin) {
		handle = pin2pwmhandle_enable(pin);
		if ((int)PIN_EINVAL == handle) {
			trace_error("%s: bad handle for pin%u",
					__func__, pin);
			return;
		}
		if (sysfsPwmDisable(handle)) {
			trace_error("%s: couldn't disable pwm "
					"on pin%u", __func__, pin);
			return;
		}

		/* Mark PWM disabled on pin */
		g_APinState[pin].uCurrentPwm = 0;
		g_APinState[pin].uPwmEnabled = 0;

		return;
	}

	trace_error("%s: unknown pin%u", __func__, pin);
}

void variantEnableFastGpio(int pin)
{
	int entryno = ardPin2DescIdx[pin];
	PinDescription *p = NULL;
	int ret = 0;

	if (entryno >= sizeof_g_APinDescription) {
		trace_error("%s: ardPin2DescIdx[%d] == %d >= "
				"sizeof_g_APinDescription", __func__, pin, entryno);
		return;
	}

	/* Enable alternate to route to SoC */
	p = &g_APinDescription[entryno];
	p->iAlternate = 1;
}

void eepromInit(void)
{
	int fd;
	char buf = 0xff;

	/* Do nothing if file exists already */
	if (access(LINUX_EEPROM, F_OK) == 0)
		return;

	if ((fd = open(LINUX_EEPROM, O_RDWR | O_CREAT, 0660)) < 0) {
		trace_error("%s Can't create EEPROM file: %s", __func__,
				strerror(errno));
		return;
	}

	if (lseek(fd, 0, SEEK_SET)) {
		trace_error("%s Can't lseek in EEPROM file: %s", __func__,
						strerror(errno));
		goto err;
	}

	if (write(fd, &buf, LINUX_EEPROM_SIZE) != LINUX_EEPROM_SIZE)
		trace_error("%s Can't write to EEPROM file: %s", __func__,
				strerror(errno));

	trace_debug("%s Created EEPROM file '%s' of size %u bytes", __func__,
			LINUX_EEPROM, LINUX_EEPROM_SIZE);
err:
	close(fd);
}

void init( int argc, char * argv[] )
{
	if(argc > 1)
		if(Serial.init_tty(argv[1]) != 0)
			return;

	if(Serial1.init_tty(LINUX_SERIAL1_TTY) != 0)
		return;
	if(Serial2.init_tty(LINUX_SERIAL2_TTY) != 0)
		return;

	sizeof_g_APinDescription = sizeof(g_APinDescription)/sizeof(struct _PinDescription);
	sizeof_g_APinState = sizeof(g_APinState)/sizeof(struct _PinState);
	pinInit();

	/* Initialize fast path to GPIO */
	if (fastGpioPciInit())
		trace_error("Unable to initialize fast GPIO mode!");

	sizeof_g_APwmDescription = sizeof(g_APwmDescription)/sizeof(struct _PwmDescription);
	pwmInit();

//	sizeof_g_AdcDescription = sizeof(g_AdcDescription)/sizeof(struct _AdcDescription);
//	adcInit();

	eepromInit();
}

